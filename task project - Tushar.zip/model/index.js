const {Sequelize,DataTypes} = require("sequelize")
const sequelize = require("../config/db");

const db = {};

db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.task = require("./task")(sequelize,DataTypes)
db.user = require("./user")(sequelize,DataTypes)





module.exports = db;



