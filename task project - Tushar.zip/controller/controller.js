const { log } = require("node:console");
const db = require("../model/index");
var jwt = require("jsonwebtoken");
const TaskTable = db.task;
const User = db.user;

const generateToken = (user_id) => {
  try {
    const token = jwt.sign({ user_id }, process.env.JWT_SECRET, {
      expiresIn: "72h",
    });
    return token;
  } catch (error) {
    throw new Error("Failed to generate token");
  }
};
const register = async (req, res) => {
  const { user_name, password } = req.body;
  try {
    const dataEntry = await User.create({ user_name, password });
    if (!dataEntry) {
      res.status(400).json({ message: "error - unable to save entry" });
    }

    res.status(200).json({ message: "sucess" });
  } catch (error) {
    console.log(error);

    res.status(400).json({ message: "Server error", error });
  }
};

const login = async (req, res) => {
  try {
    const { user_name, password } = req.body;

    const existingEmail = await User.findOne({
      where: { user_name: user_name },
    });
    if (!existingEmail) {
      res.status(400).json({ message: "no user found" });
    }
    if (existingEmail.password != password) {
      return res.status(400).json({ message: "password not matched" });
    }

    const token = generateToken(existingEmail.user_id);
    existingEmail.token = token;
    await existingEmail.save();

    res.status(200).json({ message: "login sucessfull", data: existingEmail });
  } catch (error) {
    console.log(error);

    res.status(400).json({ message: "Server error", error });
  }
};

const addTask = async (req, res) => {
  const { task_name, status } = req.body;
  try {
    const dataEntry = await TaskTable.create({ task_name, status });
    if (!dataEntry) {
      res.status(400).json({ message: "error - unable to save entry" });
    }
    res.status(200).json({ message: "sucess" });
  } catch (error) {
    console.log(error);

    res.status(400).json({ message: "Server error" });
  }
};

const updateTask = async (req, res) => {
  const { task_id, task_name, status } = req.body;
  try {
    const existingData = await TaskTable.findByPk(task_id);
    if (!existingData) {
      return res.status(400).json({ message: "invalid task id " });
    }
    if (task_name) {
      existingData.task_name = task_name;
    }
    if (status) {
      existingData.status = status;
    }

    await existingData.save();
    res.status(200).json({ message: "Data updated sucessfully", existingData });
  } catch (error) {
    res.status(400).json({ message: "Server error" });
  }
};

const getTask = async (req, res) => {
  try {
    const data = await TaskTable.findAll();
    res.status(200).json({ message: "sucess", data });
  } catch (error) {
    res.status(400).json({ message: "Server error" });
  }
};
const deleteTask = async (req, res) => {
  const { id } = req.body;
  try {
    const data = await TaskTable.findByPk(id);
    data.destroy();
    res.status(200).json({ message: "sucessfully deleted " });
  } catch (error) {
    res.status(400).json({ message: "Server error" });
  }
};

const getTaskbyStatus = async (req, res) => {
  const { status } = req.body;
  try {
    const data = await TaskTable.findAll({ where: { status: status } });
    res.status(200).json({ message: "sucess", data });
  } catch (error) {
    res.status(400).json({ message: "Server error" });
  }
};
module.exports = {
  register,
  login,
  addTask,
  updateTask,
  getTask,
  deleteTask,
  getTaskbyStatus,
};
