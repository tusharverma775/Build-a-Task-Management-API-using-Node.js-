module.exports = (sequelize, DataTypes) => {
  const taskData = sequelize.define(
    "tasks",
    {
      task_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
          primaryKey: true,
        allowNull: false,
      },
      task_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      status: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          isIn: [["Pending", "Completed"]],
        },
      },
    },
    {
      tableName: "tasks",
      timestamps: true,
    }
  );

  return taskData;
};
