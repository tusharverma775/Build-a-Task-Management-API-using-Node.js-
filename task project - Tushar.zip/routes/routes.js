const express = require('express');
const router = express.Router();
const controller = require("../controller/controller")

const {isAuthorize}= require("../helper/auth")


router.get("/api", (req, res) => {
    res.send(" hello world");
  });
  
router.post("/register", controller.register)
router.put('/login',controller.login)
router.post('/createTask',isAuthorize,controller.addTask)
router.put('/updateTask',isAuthorize,controller.updateTask)
router.get('/retriveTask', isAuthorize,controller.getTask)
router.delete('/deleteTask', isAuthorize, controller.deleteTask)
router.get('/getTaskbyStatus',controller.getTaskbyStatus)
module.exports= router